/**
 * Copyright (c) Facebook, Inc. and its affiliates. All Rights Reserved.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */

describe('a block', () => {
  beforeEach(() => {});
  afterEach(() => {});
  afterAll(() => {});
  beforeAll(() => {});
});

describe('another block with tests', () => {
  test('this test prevents us from failing due to zero tests', () => {});
});
