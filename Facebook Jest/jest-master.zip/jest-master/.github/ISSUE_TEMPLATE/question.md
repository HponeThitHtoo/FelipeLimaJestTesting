---
name: 💬 Questions / Help
label: ':speech_balloon: Question'
about: If you have questions, please check Reactiflux or StackOverflow
---

<!-- Love Jest? Please consider supporting our collective: 👉  https://opencollective.com/jest/donate -->

## 💬 Questions and Help

### Please note that this issue tracker is not a help forum and this issue will be closed.

For questions or help please see:

- [The Jest help page](https://jestjs.io/en/help.html)
- [Our `#testing` channel in Reactiflux](https://www.reactiflux.com/)
- The [jestjs](https://stackoverflow.com/questions/tagged/jestjs) tag on [StackOverflow](https://stackoverflow.com/questions/ask)
